package STARS_system;
import java.util.*;

public class menu {
	public static void main(String args[]) {
		
		menu c1 = new menu();
		c1.display_student_menu();
	}
	
	
	public void display_student_menu() {
		System.out.println("Hello");
	}
}
