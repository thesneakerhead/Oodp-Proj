package STARS_system;

public enum Department {
	CBE,
	EEE,
	CEE,
	SCSE,
	MSE,
	MAE,
	ADM,
	SSS,
	WKSCI,
	SBS,
	SPMS,
	LKCsoM,
	NIE,
	RSIS,
	ASE,
	HSS,
	NBS
}