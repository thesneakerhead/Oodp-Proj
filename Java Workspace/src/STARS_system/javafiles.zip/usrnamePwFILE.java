package STARS_system;

public class usrnamePwFILE {
	private static String studentfilename = "sLoginDB.txt";
	private static String adminfilename = "aLoginDB.txt";
	public static String getStudentFilename() {
		return studentfilename;
	}
	public static String getAdminFilename() {
		return adminfilename;
	}
}
